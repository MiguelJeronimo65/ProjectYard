# ProjectYard Architecture
ASP.NET Core MVC + Materio + EF Core 10 + Finbuckle.MultiTenant.
