# DFD
Fluxos principais de tenant, projetos, aprovações e pagamentos.
