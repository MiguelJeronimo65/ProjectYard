# Database Design
Contém entidades multi-tenant, projetos, tarefas, documentos e pagamentos.
