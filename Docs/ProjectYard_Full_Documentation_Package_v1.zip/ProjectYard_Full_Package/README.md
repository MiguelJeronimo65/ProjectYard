# ProjectYard

**ProjectYard** é uma plataforma SaaS multi-tenant para gestão colaborativa e controlo profissional de projetos.

Este pacote contém a documentação inicial completa para arrancar o desenvolvimento em:

- ASP.NET Core MVC / .NET 10
- EF Core 10
- Clean Architecture
- Finbuckle.MultiTenant
- Materio Admin Template
- Base documental separada `ProjectYardDocuments`
- SMS bidirecional
- Controlo de custos, pagamentos, prazos, aprovações e entregáveis

## Estrutura

```text
ProjectYard/
├── Docs/
│   ├── 00_Product/
│   ├── 01_Architecture/
│   ├── 02_DFD/
│   ├── 03_Database/
│   ├── 04_Modules/
│   ├── 05_Screens/
│   ├── 06_Roadmap/
│   └── 07_Development/
├── src/
│   ├── ProjectYard.Web/
│   ├── ProjectYard.Application/
│   ├── ProjectYard.Domain/
│   ├── ProjectYard.Infrastructure/
│   └── ProjectYard.Documents/
└── tests/
```
