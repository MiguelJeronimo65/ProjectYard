# ProjectYard — Data Flow Diagrams

## 1. DFD Nível 0

```text
+---------------------+       +---------------------+
| Cliente / Contacto  | <---> |      ProjectYard    |
+---------------------+       +----------+----------+
                                         |
                                         v
                              +---------------------+
                              | ProjectYardDocuments|
                              +---------------------+
                                         |
                                         v
                              +---------------------+
                              | Gateway SMS / Email |
                              +---------------------+
```

## 2. DFD Nível 1

```text
[Superadmin]
     |
     v
(1) Gestão de Tenants
     |
     +--> Tenants
     +--> TenantPlans
     +--> TrialAccess

[Admin Tenant]
     |
     v
(2) Utilizadores e Permissões
     |
     +--> Users
     +--> Roles
     +--> Permissions

[Gestor Projeto]
     |
     v
(3) Gestão de Projetos
     |
     +--> Projects
     +--> ProjectPhases
     +--> ProjectMembers
     +--> ProjectTools

[Equipa]
     |
     v
(4) Execução
     |
     +--> ProjectTasks
     +--> ProjectSubTasks
     +--> ProjectDeliverables
     +--> DocumentFiles

[Cliente]
     |
     v
(5) Aprovações e Comunicação
     |
     +--> Approvals
     +--> ApprovalSteps
     +--> SmsMessages
     +--> ProjectMessages

[Financeiro]
     |
     v
(6) Custos e Pagamentos
     |
     +--> ProjectCosts
     +--> PaymentMilestones
     +--> Invoices
     +--> Payments
```

## 3. DFD — Criar Tenant Trial

```text
Superadmin
   |
   v
Criar Tenant
   |
   +--> Tenants
   +--> TenantSettings
   +--> TrialAccess
   +--> Users
   +--> Roles
   +--> Permissions
   |
   v
Enviar convite
   |
   +--> Notifications
   +--> SmsMessages / Email
```

## 4. DFD — Criar Projeto

```text
TenantAdmin / ProjectManager
   |
   v
Criar Projeto
   |
   +--> Projects
   +--> ProjectMembers
   +--> ProjectTools
   +--> ProjectSettings
   |
   v
Criar Fases
   |
   +--> ProjectPhases
   +--> Deadlines
   +--> ProjectMilestones
   |
   v
Criar Tasks / Entregáveis
   |
   +--> ProjectTasks
   +--> ProjectSubTasks
   +--> ProjectDeliverables
```

## 5. DFD — Entregável

```text
Colaborador
   |
   v
Produz Entregável
   |
   +--> ProjectDeliverables
   +--> DeliverableVersions
   +--> DocumentFiles
   |
   v
Submete para Aprovação
   |
   +--> Approvals
   +--> ApprovalSteps
   +--> Notifications
   +--> SmsMessages
```

## 6. DFD — Aprovação

```text
Cliente/Aprovador
   |
   v
Recebe Notificação / SMS
   |
   v
Aprova ou Rejeita
   |
   +--> ApprovalSteps
   +--> Approvals
   +--> ActivityLog
   |
   v
Se aprovado:
   +--> atualizar Deliverable
   +--> verificar PaymentMilestone

Se rejeitado:
   +--> marcar NeedsRevision
   +--> criar comentário
   +--> notificar responsável
```

## 7. DFD — Pagamento por Milestone

```text
Milestone atingida
   |
   v
Validar condição
   |
   +--> PaymentMilestones
   |
   v
Gerar Invoice
   |
   +--> Invoices
   |
   v
Notificar Cliente
   |
   +--> Notifications
   +--> SmsMessages
   |
   v
Registar Pagamento
   |
   +--> Payments
   +--> DocumentFiles como comprovativo
```

## 8. DFD — SMS Bidirecional

```text
Sistema
   |
   v
Criar SMS Outbound
   |
   +--> SmsMessages
   |
   v
Gateway SMS
   |
   v
Atualizar estado

Cliente responde
   |
   v
Gateway Webhook
   |
   v
Processar inbound
   |
   +--> identificar Contact/User
   +--> identificar Tenant
   +--> identificar Project/WorkItem
   +--> aplicar SmsReplyRules
   |
   v
Criar comentário / aprovar / rejeitar / criar tarefa
```

## 9. DFD — Change Request

```text
Pedido extra
   |
   v
Verificar exclusões
   |
   +--> ProjectExclusions
   |
   v
Criar Change Request
   |
   +--> ProjectChangeRequests
   |
   v
Avaliar impacto
   |
   +--> custo
   +--> prazo
   +--> documentos
   |
   v
Aprovação
   |
   +--> Approvals
```

