# ProjectYard — Módulos Funcionais

## 1. Tenant Management

Funções:

- criar tenant;
- criar trial 30 dias;
- suspender tenant;
- converter trial em cliente;
- configurar plano;
- definir limites;
- controlar storage;
- configurar SMS/email.

## 2. User Management

Funções:

- criar utilizadores;
- convidar por email;
- convidar por SMS;
- atribuir roles;
- ativar/desativar;
- gerir permissões;
- gerir clientes/convidados.

## 3. Projects

Funções:

- criar projeto;
- definir cliente;
- definir gestor;
- configurar ferramentas;
- adicionar membros;
- controlar estado;
- controlar saúde;
- controlar progresso.

## 4. Project Tools

Ferramentas ativáveis:

```text
Message Board
To-dos
Docs & Files
Calendar
Chat
Card Table
Check-ins
External Links
Decisions
Risks
Approvals
Costs
Payments
Reports
```

## 5. Tasks / Subtasks

Funções:

- task por fase;
- task por especialidade;
- subtasks;
- checklist;
- responsáveis;
- prioridades;
- dependências;
- prazos;
- comentários;
- anexos;
- aprovação.

## 6. Deliverables

Funções:

- criar entregável;
- associar a fase/task/especialidade;
- versionar;
- anexar documentos;
- submeter para aprovação;
- controlar estado;
- controlar prazo.

## 7. Documents

Funções:

- upload;
- versões;
- ligação a qualquer entidade;
- download;
- preview futuro;
- logs de acesso;
- storage separado.

## 8. Approvals

Funções:

- aprovação de entregável;
- aprovação de orçamento;
- aprovação de pagamento;
- aprovação de change request;
- aprovação por SMS;
- histórico de decisão.

## 9. Cost Control

Funções:

- custos previstos;
- custos reais;
- custos por fase;
- custos por fornecedor;
- custos extra;
- variação;
- relatório financeiro.

## 10. Payments

Funções:

- plano de pagamentos;
- milestones;
- faturas;
- comprovativos;
- alertas de vencimento;
- pagamento parcial;
- estado de pagamento.

## 11. SMS

Funções:

- templates;
- envio manual;
- envio automático;
- resposta inbound;
- regras por keyword;
- associação a projeto/aprovação/tarefa;
- histórico.

## 12. Deadlines

Funções:

- prazos por entidade;
- alertas antes/depois;
- histórico de alteração;
- escalonamento;
- dashboard de atrasos.

## 13. Risks / Blockers

Funções:

- registar riscos;
- probabilidade;
- impacto;
- severidade;
- mitigação;
- blockers de tasks;
- responsável por desbloquear.

## 14. Change Requests

Funções:

- pedido extra;
- impacto em custo;
- impacto em prazo;
- aprovação;
- ligação a exclusões;
- implementação.

## 15. Reports

Relatórios:

- projeto;
- financeiro;
- atrasos;
- entregáveis;
- aprovações;
- riscos;
- SMS;
- auditoria.

