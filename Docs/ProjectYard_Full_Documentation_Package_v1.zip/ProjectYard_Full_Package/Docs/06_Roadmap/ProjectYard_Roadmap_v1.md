# ProjectYard — Roadmap

## MVP

Objetivo: ter um sistema usável para controlar projetos simples com documentos e tarefas.

Inclui:

- multi-tenant básico;
- superadmin;
- trial 30 dias;
- utilizadores;
- roles;
- projetos;
- membros;
- fases;
- tasks;
- subtasks;
- documentos;
- prazos;
- comentários;
- atividade.

## V1

Objetivo: tornar o sistema útil para projetos profissionais.

Inclui:

- entregáveis;
- aprovações;
- custos;
- pagamentos;
- milestones;
- notificações;
- base documental separada;
- dashboards.

## V2

Objetivo: automatizar controlo e comunicação.

Inclui:

- SMS outbound;
- SMS inbound;
- templates SMS;
- reply rules;
- change requests;
- exclusões;
- riscos;
- blockers;
- visitas;
- relatórios.

## V3

Objetivo: colaboração avançada.

Inclui:

- Kanban;
- chat;
- calendar;
- check-ins;
- project templates;
- automações;
- escalonamentos.

## Enterprise

Inclui:

- DB dedicada por tenant;
- storage dedicado;
- API pública;
- webhooks;
- OCR;
- IA;
- assinatura digital;
- integração com faturação;
- integração com pagamentos;
- dashboards BI.

