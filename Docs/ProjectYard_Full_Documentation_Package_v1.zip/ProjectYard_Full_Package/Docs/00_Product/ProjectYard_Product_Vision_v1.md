# ProjectYard — Visão do Produto

## 1. Nome

**ProjectYard**

## 2. Tagline proposta

> Where projects move forward.

## 3. Posicionamento

ProjectYard é uma plataforma de **Project Delivery Control**.  
A inspiração conceptual vem de plataformas colaborativas como Basecamp, mas o ProjectYard vai além da colaboração simples, adicionando controlo profissional de:

- fases;
- tarefas;
- subtarefas;
- entregáveis;
- documentos;
- aprovações;
- custos;
- pagamentos;
- prazos;
- riscos;
- SMS bidirecional;
- multi-tenant;
- trial de 30 dias;
- auditoria;
- base documental separada.

## 4. Problema que resolve

Muitos projetos profissionais são geridos com uma mistura de email, WhatsApp, Excel, PDFs, pastas partilhadas e chamadas telefónicas.

Isto causa:

- perda de decisões;
- atrasos sem dono claro;
- documentos desorganizados;
- entregáveis sem versão;
- pagamentos sem ligação a milestones;
- falta de histórico;
- dificuldade em controlar fornecedores/clientes;
- pouca rastreabilidade;
- inexistência de alertas e escalonamento.

## 5. Solução

ProjectYard centraliza o projeto inteiro:

```text
Projeto
 ├── Fases
 ├── Tasks/Subtasks
 ├── Entregáveis
 ├── Documentos
 ├── Aprovações
 ├── Custos
 ├── Pagamentos
 ├── SMS
 ├── Prazos
 ├── Riscos
 └── Relatórios
```

## 6. Público-alvo

- gabinetes de arquitetura;
- empresas de engenharia;
- consultoras;
- PMOs;
- empresas de software;
- empresas de remodelação/obra;
- gestores de projeto;
- equipas técnicas;
- prestadores de serviços profissionais.

## 7. Diferenciação face a Basecamp

| Basecamp | ProjectYard |
|---|---|
| Project workspace simples | Project delivery control completo |
| Comunicação e tarefas | Entregáveis, pagamentos, riscos e prazos |
| Pouco controlo financeiro | Custos, invoices, milestones e pagamentos |
| Documentos simples | Base documental separada com versões |
| Sem SMS bidirecional forte | SMS outbound/inbound com regras |
| Pouco orientado a contratos | Âmbito, exclusões e change requests |
| Reporting limitado | Dashboards operacionais e financeiros |

## 8. Produto SaaS

ProjectYard deve nascer como SaaS multi-tenant:

- Superadmin global;
- tenants independentes;
- trial de 30 dias;
- planos;
- limites por plano;
- auditoria;
- possibilidade futura de base dedicada por tenant enterprise.

