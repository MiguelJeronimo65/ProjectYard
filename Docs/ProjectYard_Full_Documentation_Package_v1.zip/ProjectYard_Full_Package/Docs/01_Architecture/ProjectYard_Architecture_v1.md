# ProjectYard — Arquitetura Técnica

## 1. Stack oficial

```text
Frontend/UI: Materio Admin Template
Backend: ASP.NET Core MVC / .NET 10
ORM: EF Core 10
Auth: ASP.NET Identity
Multi-Tenant: Finbuckle.MultiTenant
Architecture: Clean Architecture
Jobs: Hangfire ou Quartz.NET
Main DB: ProjectYard
Documents DB: ProjectYardDocuments
SMS: Gateway com Webhook
```

## 2. Estrutura da Solution

```text
ProjectYard.sln

src/
├── ProjectYard.Web
├── ProjectYard.Application
├── ProjectYard.Domain
├── ProjectYard.Infrastructure
├── ProjectYard.Documents
└── ProjectYard.Shared

tests/
├── ProjectYard.UnitTests
└── ProjectYard.IntegrationTests
```

## 3. Responsabilidade por projeto

### `ProjectYard.Web`

- ASP.NET Core MVC;
- Controllers;
- Razor Views;
- ViewModels;
- integração do Materio;
- autenticação;
- autorização;
- menus;
- dashboards;
- upload/download;
- endpoints webhook SMS.

### `ProjectYard.Application`

- casos de uso;
- DTOs;
- Commands;
- Queries;
- validações;
- serviços de aplicação;
- orquestração de workflows;
- regras de negócio de aplicação.

### `ProjectYard.Domain`

- entidades;
- enums;
- value objects;
- regras de domínio;
- eventos de domínio;
- interfaces core.

### `ProjectYard.Infrastructure`

- DbContext principal;
- EF Core;
- repositórios;
- Identity;
- Finbuckle;
- SMS provider;
- email provider;
- notifications;
- background jobs;
- audit logging.

### `ProjectYard.Documents`

- DbContext documental;
- armazenamento de ficheiros;
- versões;
- links de documentos;
- logs de acesso;
- integração com local storage, Azure Blob ou S3.

## 4. Multi-Tenant

### Estratégia inicial

```text
Shared database + TenantId obrigatório
```

Todas as tabelas funcionais devem ter `TenantId`.

### Estratégia futura Enterprise

```text
Tenant dedicado com DB própria
```

## 5. Superadmin

O Superadmin é global e pode:

- criar tenants;
- criar trials;
- suspender tenants;
- alterar planos;
- consultar auditoria;
- gerir limites;
- ver métricas globais;
- configurar gateways SMS/email.

## 6. Trial 30 dias

Fluxo:

```text
Superadmin cria tenant trial
  → tenant fica TrialActive
  → TrialEndAt = CreatedAt + 30 dias
  → avisos antes de expirar
  → após expirar: TrialExpired
  → superadmin pode estender ou converter
```

## 7. Base documental separada

### Main DB `ProjectYard`

Guarda:

- tenants;
- utilizadores;
- projetos;
- tasks;
- permissões;
- metadados;
- custos;
- pagamentos;
- SMS;
- notificações.

### Documents DB `ProjectYardDocuments`

Guarda:

- DocumentFiles;
- DocumentVersions;
- DocumentLinks;
- DocumentAccessLog;
- thumbnails;
- metadados;
- storage paths;
- opcionalmente blobs.

## 8. Materio

O Materio será usado como camada visual.

Áreas a adaptar:

- layout principal;
- menu lateral;
- dashboard cards;
- data tables;
- forms;
- wizards;
- timeline;
- notifications;
- calendar;
- kanban;
- chat;
- invoice pages;
- role/permission pages.

## 9. Background Jobs

Usar Hangfire/Quartz para:

- alertas de prazo;
- expiração de trial;
- pagamentos vencidos;
- envio de SMS;
- envio de email;
- processamento de respostas SMS;
- criação de notificações;
- geração de relatórios.

## 10. Segurança

- ASP.NET Identity;
- 2FA futura;
- políticas por role;
- filtro por TenantId;
- auditoria;
- logs de acesso a documentos;
- proteção contra acesso cross-tenant;
- validação em todos os serviços.

