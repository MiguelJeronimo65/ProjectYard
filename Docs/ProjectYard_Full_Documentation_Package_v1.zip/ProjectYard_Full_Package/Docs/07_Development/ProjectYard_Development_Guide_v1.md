# ProjectYard — Guia de Desenvolvimento

## 1. Template escolhido

**Materio**

O Materio será usado como camada visual/admin template.

## 2. Stack

```text
ASP.NET Core MVC / .NET 10
EF Core 10
ASP.NET Identity
Finbuckle.MultiTenant
Clean Architecture
Materio
Hangfire
```

## 3. Primeira ordem de implementação

```text
1. Criar solution
2. Criar projetos
3. Integrar Materio no ProjectYard.Web
4. Configurar Identity
5. Configurar Finbuckle
6. Criar Tenant model
7. Criar DbContext principal
8. Criar DbContext documental
9. Criar Users/Roles
10. Criar Projects
11. Criar Phases
12. Criar Tasks/SubTasks
13. Criar Documents
```

## 4. Namespaces

```text
ProjectYard.Domain
ProjectYard.Application
ProjectYard.Infrastructure
ProjectYard.Documents
ProjectYard.Web
```

## 5. DbContexts

```text
ProjectYardDbContext
ProjectYardIdentityDbContext
ProjectYardDocumentsDbContext
```

## 6. Primeiras entidades a criar

```text
Tenant
TenantPlan
TrialAccess
ApplicationUser
Role
Permission
Company
Contact
Project
ProjectMember
ProjectPhase
ProjectTask
ProjectSubTask
DocumentFile
DocumentVersion
DocumentLink
```

## 7. Migrations iniciais

```text
InitialIdentity
InitialTenancy
InitialProjects
InitialDocuments
```

## 8. Convenções MVC

Controllers:

```text
TenantsController
ProjectsController
ProjectPhasesController
ProjectTasksController
DocumentsController
ApprovalsController
PaymentsController
SmsController
```

Views:

```text
Views/Tenants
Views/Projects
Views/Tasks
Views/Documents
Views/Approvals
Views/Payments
Views/Sms
```

ViewModels:

```text
ProjectCreateViewModel
ProjectDashboardViewModel
TaskDetailViewModel
DeliverableDetailViewModel
PaymentMilestoneViewModel
```

## 9. Tenant Filter

Todas as queries funcionais devem filtrar por TenantId.

## 10. Segurança

Nunca confiar apenas na UI.  
Validar permissões na camada Application/Infrastructure.

