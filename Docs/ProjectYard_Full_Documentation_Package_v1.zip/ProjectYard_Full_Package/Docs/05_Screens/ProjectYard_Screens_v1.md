# ProjectYard — Ecrãs

## 1. Superadmin

```text
Dashboard Global
Tenants
Criar Tenant Trial
Planos
Utilizadores Globais
SMS Global
Auditoria
Configurações
```

## 2. Tenant Admin

```text
Dashboard Tenant
Utilizadores
Roles
Permissões
Empresas
Contactos
Configurações
Templates SMS
```

## 3. Projetos

```text
Lista de Projetos
Criar Projeto
Editar Projeto
Dashboard do Projeto
Membros
Ferramentas
Atividade
```

## 4. Project Dashboard

Widgets:

```text
Estado do projeto
Progresso
Tarefas abertas
Tarefas em atraso
Entregáveis pendentes
Aprovações pendentes
Pagamentos pendentes
Riscos abertos
Atividade recente
```

## 5. Fases

```text
Lista de fases
Detalhe da fase
Tasks da fase
Entregáveis da fase
Pagamentos associados
Prazos
```

## 6. Tasks

```text
Lista
Kanban
Detalhe da task
Subtasks
Checklist
Comentários
Anexos
Dependências
Histórico
```

## 7. Entregáveis

```text
Lista
Detalhe
Versões
Documentos
Submeter para aprovação
Estado
Comentários
```

## 8. Documentos

```text
Biblioteca
Pastas
Upload
Versões
Detalhe do documento
Histórico de acesso
Documentos ligados
```

## 9. Aprovações

```text
Pendentes
Detalhe
Passos
Aprovar
Rejeitar
Pedir alterações
Histórico
```

## 10. Financeiro

```text
Custos
Plano de pagamentos
Milestones
Faturas
Pagamentos
Comprovativos
Relatório financeiro
```

## 11. SMS

```text
SMS enviados
SMS recebidos
Templates
Regras de resposta
Detalhe da conversa
SMS não associados
```

## 12. Riscos

```text
Lista
Matriz probabilidade/impacto
Detalhe
Mitigações
Bloqueios
```

## 13. Reports

```text
Relatório do projeto
Relatório financeiro
Relatório de atrasos
Relatório de entregáveis
Relatório de aprovações
Relatório de SMS
```

