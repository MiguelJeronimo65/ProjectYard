# ProjectYard — Database Design

## 1. Bases de dados

```text
ProjectYard
ProjectYardDocuments
```

## 2. Convenções

Todas as tabelas funcionais devem conter:

```text
Id
TenantId
CreatedAt
UpdatedAt
DeletedAt
CreatedByUserId
UpdatedByUserId
```

Campos opcionais conforme o caso:

```text
Uid
Status
RowVersion
IsDeleted
```

## 3. Tabelas de administração

### Tenants

```text
Id PK
Uid
Name
Slug
LegalName
TaxNumber
Email
Phone
Status
PlanId FK
TrialStartAt
TrialEndAt
IsTrial
IsActive
CreatedAt
UpdatedAt
DeletedAt
```

### TenantPlans

```text
Id PK
Code
Name
Description
MaxUsers
MaxProjects
MaxStorageMb
AllowsSms
AllowsApi
AllowsCustomBranding
MonthlyPrice
YearlyPrice
IsActive
CreatedAt
```

### TenantSettings

```text
Id PK
TenantId FK
DefaultLanguage
DefaultTimeZone
BrandLogoUrl
PrimaryColor
SmsEnabled
EmailEnabled
DocumentStorageMode
SettingsJson
CreatedAt
UpdatedAt
```

### TrialAccess

```text
Id PK
TenantId FK
CreatedBySuperAdminId FK
StartAt
EndAt
Status
ExtendedUntil
ExtensionReason
ConvertedAt
CancelledAt
CreatedAt
```

### SuperAdminUsers

```text
Id PK
UserId FK
IsOwner
CanManageTenants
CanViewBilling
CanViewAudit
CreatedAt
```

## 4. Utilizadores e permissões

### Users

```text
Id PK
TenantId FK NULL
IdentityUserId
DisplayName
Email
PhoneNumber
AvatarUrl
UserType
IsSuperAdmin
IsTenantAdmin
IsActive
LastLoginAt
CreatedAt
UpdatedAt
DeletedAt
```

### Roles

```text
Id PK
TenantId FK NULL
Name
Code
Description
IsSystemRole
CreatedAt
UpdatedAt
```

### Permissions

```text
Id PK
Code
Name
Description
Module
CreatedAt
```

### RolePermissions

```text
Id PK
RoleId FK
PermissionId FK
CreatedAt
```

### UserRoles

```text
Id PK
UserId FK
RoleId FK
ScopeType
ScopeId
CreatedAt
CreatedByUserId FK
```

## 5. Empresas e contactos

### Companies

```text
Id PK
TenantId FK
Name
CompanyType
TaxNumber
Email
Phone
Website
Address
PostalCode
City
Country
Notes
IsActive
CreatedAt
UpdatedAt
DeletedAt
```

### Contacts

```text
Id PK
TenantId FK
CompanyId FK
Name
Email
Phone
Role
IsPrimary
CanReceiveSms
CanApprove
CreatedAt
UpdatedAt
DeletedAt
```

## 6. Projetos

### Projects

```text
Id PK
TenantId FK
ClientCompanyId FK
Name
ProjectCode
Description
ProjectType
Status
HealthStatus
ProgressPercent
StartDate
PlannedEndDate
RevisedEndDate
ActualEndDate
ContractAmount
BudgetAmount
Currency
ProjectManagerUserId FK
CreatedAt
UpdatedAt
DeletedAt
```

### ProjectMembers

```text
Id PK
TenantId FK
ProjectId FK
UserId FK
RoleId FK
MemberType
CanView
CanComment
CanCreateTasks
CanManageTasks
CanUploadFiles
CanViewFinancials
CanManageProject
JoinedAt
RemovedAt
CreatedAt
```

### ProjectTools

```text
Id PK
TenantId FK
ProjectId FK
ToolCode
Title
Description
IsEnabled
Position
SettingsJson
CreatedAt
UpdatedAt
```

### ProjectSettings

```text
Id PK
TenantId FK
ProjectId FK
DefaultVisibility
AllowClientAccess
AllowClientComments
AllowClientFileUpload
EnableSmsAlerts
EnableCostControl
EnableDeadlineEscalation
SettingsJson
CreatedAt
UpdatedAt
```

## 7. Fases, milestones e prazos

### ProjectPhases

```text
Id PK
TenantId FK
ProjectId FK
Name
Description
PhaseOrder
PhaseType
Status
StartDate
PlannedEndDate
RevisedEndDate
ActualEndDate
RequiresApproval
ApprovedAt
ApprovedByUserId FK
ProgressPercent
CreatedAt
UpdatedAt
```

### ProjectMilestones

```text
Id PK
TenantId FK
ProjectId FK
PhaseId FK
Name
Description
MilestoneType
DueDate
CompletedAt
Status
TriggersPayment
CreatedAt
UpdatedAt
```

### Deadlines

```text
Id PK
TenantId FK
ProjectId FK
EntityType
EntityId
Title
OriginalDueDate
CurrentDueDate
CompletedAt
Status
ReminderPolicyId FK
EscalationPolicyId FK
ResponsibleUserId FK
CreatedAt
UpdatedAt
```

### DeadlineChanges

```text
Id PK
TenantId FK
DeadlineId FK
OldDueDate
NewDueDate
Reason
ChangedByUserId FK
CreatedAt
```

## 8. WorkItems

### WorkItems

```text
Id PK
TenantId FK
ProjectId FK
ParentWorkItemId FK NULL
ItemType
SourceTable
SourceId
Title
Summary
Status
Visibility
IsClientVisible
IsPinned
IsLocked
CommentsCount
AttachmentsCount
SubscribersCount
LastActivityAt
CreatedByUserId FK
UpdatedByUserId FK
CreatedAt
UpdatedAt
ArchivedAt
DeletedAt
```

## 9. Tasks

### ProjectTasks

```text
Id PK
TenantId FK
ProjectId FK
PhaseId FK
WorkItemId FK
SpecialtyId FK NULL
Title
Description
TaskType
Status
Priority
WorkflowStatus
AssignedOwnerUserId FK
StartDate
DueDate
CompletedAt
ProgressPercent
RequiresApproval
ApprovedAt
CreatedAt
UpdatedAt
```

### ProjectSubTasks

```text
Id PK
TenantId FK
TaskId FK
Title
Description
Status
AssignedToUserId FK
DueDate
CompletedAt
Position
CreatedAt
UpdatedAt
```

### TaskAssignments

```text
Id PK
TenantId FK
TaskId FK
UserId FK
AssignedByUserId FK
AssignedAt
UnassignedAt
```

### TaskDependencies

```text
Id PK
TenantId FK
TaskId FK
DependsOnTaskId FK
DependencyType
CreatedAt
```

### TaskChecklistItems

```text
Id PK
TenantId FK
TaskId FK
Title
Position
IsCompleted
CompletedAt
CompletedByUserId FK
CreatedAt
UpdatedAt
```

## 10. Especialidades

### ProjectSpecialties

```text
Id PK
TenantId FK
ProjectId FK
Code
Name
Description
ResponsibleUserId FK
ExternalEntityId FK NULL
Status
StartDate
DueDate
CompletedAt
RequiresSubmission
RequiresTechnicalDeclaration
CreatedAt
UpdatedAt
```

## 11. Entregáveis

### ProjectDeliverables

```text
Id PK
TenantId FK
ProjectId FK
PhaseId FK
TaskId FK NULL
SpecialtyId FK NULL
WorkItemId FK
Name
Description
DeliverableType
Required
Status
DueDate
SubmittedAt
ReviewedAt
ApprovedAt
RejectedAt
CurrentVersionId FK
CreatedAt
UpdatedAt
```

### DeliverableVersions

```text
Id PK
TenantId FK
DeliverableId FK
VersionNumber
DocumentFileId FK
ChangeSummary
SubmittedByUserId FK
SubmittedAt
Status
CreatedAt
```

### DeliverableApprovals

```text
Id PK
TenantId FK
DeliverableId FK
ApprovalId FK
CreatedAt
```

## 12. Aprovações

### Approvals

```text
Id PK
TenantId FK
ProjectId FK
WorkItemId FK NULL
ApprovalType
Title
Description
Status
RequestedByUserId FK
RequestedAt
CompletedAt
CreatedAt
UpdatedAt
```

### ApprovalSteps

```text
Id PK
TenantId FK
ApprovalId FK
StepNumber
ApproverUserId FK
ApproverContactId FK NULL
Status
Comment
RespondedAt
CreatedAt
UpdatedAt
```

## 13. Financeiro

### ProjectCosts

```text
Id PK
TenantId FK
ProjectId FK
PhaseId FK NULL
TaskId FK NULL
CostCategory
Description
SupplierCompanyId FK NULL
AmountWithoutVat
VatRate
VatAmount
TotalAmount
Currency
CostStatus
ExpectedDate
ActualDate
CreatedAt
UpdatedAt
```

### PaymentMilestones

```text
Id PK
TenantId FK
ProjectId FK
PhaseId FK NULL
MilestoneId FK NULL
Name
Description
Percentage
AmountWithoutVat
VatRate
VatAmount
TotalAmount
TriggerType
TriggerEntityType
TriggerEntityId
DueDate
Status
InvoiceId FK NULL
PaidAt
CreatedAt
UpdatedAt
```

### Invoices

```text
Id PK
TenantId FK
ProjectId FK
InvoiceNumber
InvoiceDate
DueDate
AmountWithoutVat
VatAmount
TotalAmount
Currency
Status
DocumentFileId
CreatedAt
UpdatedAt
```

### Payments

```text
Id PK
TenantId FK
ProjectId FK
InvoiceId FK NULL
PaymentMilestoneId FK NULL
PaymentDate
Amount
PaymentMethod
Reference
Status
ProofDocumentFileId
CreatedAt
UpdatedAt
```

## 14. Documentos — ProjectYardDocuments

### DocumentFiles

```text
Id PK
TenantId
ProjectId
DocumentType
OriginalFileName
StoredFileName
FileExtension
MimeType
FileSizeBytes
Checksum
StorageProvider
StoragePath
BlobData NULL
UploadedByUserId
UploadedAt
Status
CreatedAt
DeletedAt
```

### DocumentVersions

```text
Id PK
TenantId
DocumentFileId FK
VersionNumber
OriginalFileName
StoragePath
Checksum
FileSizeBytes
UploadedByUserId
ChangeSummary
CreatedAt
```

### DocumentLinks

```text
Id PK
TenantId
DocumentFileId FK
EntityType
EntityId
LinkedByUserId
CreatedAt
```

### DocumentAccessLog

```text
Id PK
TenantId
DocumentFileId FK
UserId
ActionType
IpAddress
UserAgent
CreatedAt
```

## 15. Comunicação

### ProjectMessages

```text
Id PK
TenantId FK
ProjectId FK
WorkItemId FK
Title
ContentHtml
ContentText
AuthorUserId FK
Visibility
Status
PublishedAt
CreatedAt
UpdatedAt
DeletedAt
```

### Comments

```text
Id PK
TenantId FK
ProjectId FK
WorkItemId FK
ParentCommentId FK NULL
AuthorUserId FK
ContentHtml
ContentText
Visibility
Status
CreatedAt
UpdatedAt
DeletedAt
```

## 16. SMS

### SmsMessages

```text
Id PK
TenantId FK
ProjectId FK NULL
WorkItemId FK NULL
Direction
FromNumber
ToNumber
ContactId FK NULL
UserId FK NULL
MessageText
Provider
ProviderMessageId
Status
ErrorMessage
SentAt
DeliveredAt
ReceivedAt
ProcessedAt
CreatedAt
```

### SmsTemplates

```text
Id PK
TenantId FK NULL
Code
Name
TemplateText
IsSystemTemplate
CreatedAt
UpdatedAt
```

### SmsReplyRules

```text
Id PK
TenantId FK
Keyword
ActionType
TargetEntityType
IsActive
CreatedAt
UpdatedAt
```

## 17. Notificações

### Notifications

```text
Id PK
TenantId FK
ProjectId FK NULL
WorkItemId FK NULL
NotificationType
Title
Body
ActorUserId FK NULL
MetadataJson
CreatedAt
```

### NotificationRecipients

```text
Id PK
TenantId FK
NotificationId FK
UserId FK NULL
ContactId FK NULL
DeliveryChannel
IsRead
ReadAt
IsDismissed
DismissedAt
DeliveredAt
FailedAt
FailureReason
CreatedAt
```

## 18. Change Requests e Exclusões

### ProjectChangeRequests

```text
Id PK
TenantId FK
ProjectId FK
Title
Description
Reason
RequestedByUserId FK NULL
RequestedByContactId FK NULL
RequestDate
ImpactOnCost
ImpactOnSchedule
AdditionalAmount
AdditionalDays
Status
ApprovedByUserId FK NULL
ApprovedAt
RejectedAt
CreatedAt
UpdatedAt
```

### ProjectExclusions

```text
Id PK
TenantId FK
ProjectId FK
Category
Description
SourceReference
RequiresChangeRequest
CanBeQuotedSeparately
AcknowledgedByClient
AcknowledgedAt
CreatedAt
UpdatedAt
```

## 19. Visitas

### ProjectSiteVisits

```text
Id PK
TenantId FK
ProjectId FK
VisitDate
Period
VisitType
ResponsibleUserId FK
Description
Findings
ActionsRequired
Cost
Billable
InvoiceId FK NULL
Status
CreatedAt
UpdatedAt
```

### SiteVisitPhotos

```text
Id PK
TenantId FK
SiteVisitId FK
DocumentFileId
Caption
CreatedAt
```

## 20. Riscos e bloqueios

### ProjectRisks

```text
Id PK
TenantId FK
ProjectId FK
WorkItemId FK NULL
Title
Description
Category
Probability
Impact
Severity
OwnerUserId FK
MitigationPlan
Status
DueDate
CreatedAt
UpdatedAt
ClosedAt
```

### ProjectBlockers

```text
Id PK
TenantId FK
ProjectId FK
TaskId FK NULL
Title
Description
BlockedBy
ResponsibleUserId FK
Status
CreatedAt
ResolvedAt
```

## 21. Auditoria

### ActivityLog

```text
Id PK
TenantId FK
ProjectId FK NULL
WorkItemId FK NULL
ActorUserId FK NULL
ActionType
EntityType
EntityId
Title
Description
MetadataJson
CreatedAt
```

### AuditLog

```text
Id PK
TenantId FK NULL
ActorUserId FK NULL
Action
EntityType
EntityId
OldValuesJson
NewValuesJson
IpAddress
UserAgent
CreatedAt
```

## 22. Relações principais

```text
Tenants 1:N Users
Tenants 1:N Projects
Projects 1:N ProjectPhases
Projects 1:N ProjectTasks
Projects 1:N ProjectDeliverables
Projects 1:N PaymentMilestones
ProjectPhases 1:N ProjectTasks
ProjectTasks 1:N ProjectSubTasks
ProjectTasks N:N Users via TaskAssignments
ProjectTasks N:N ProjectTasks via TaskDependencies
ProjectDeliverables 1:N DeliverableVersions
Approvals 1:N ApprovalSteps
Invoices 1:N Payments
DocumentFiles 1:N DocumentVersions
DocumentFiles 1:N DocumentLinks
WorkItems 1:N Comments
WorkItems 1:N Notifications
```

## 23. Índices recomendados

```text
Tenants(Slug)
Users(TenantId, Email)
Projects(TenantId, Status)
Projects(TenantId, ProjectManagerUserId)
ProjectTasks(TenantId, ProjectId, Status)
ProjectTasks(TenantId, DueDate)
ProjectDeliverables(TenantId, ProjectId, Status)
Deadlines(TenantId, CurrentDueDate, Status)
PaymentMilestones(TenantId, ProjectId, Status)
SmsMessages(TenantId, ProjectId, Status)
DocumentFiles(TenantId, ProjectId)
ActivityLog(TenantId, ProjectId, CreatedAt)
AuditLog(TenantId, CreatedAt)
```

