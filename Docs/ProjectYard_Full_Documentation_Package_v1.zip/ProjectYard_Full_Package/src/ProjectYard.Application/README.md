# ProjectYard.Application

Placeholder para implementação futura.
