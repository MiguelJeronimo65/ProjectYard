# ProjectYard.Infrastructure

Placeholder para implementação futura.
