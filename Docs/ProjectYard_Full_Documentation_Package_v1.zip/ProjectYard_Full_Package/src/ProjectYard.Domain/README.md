# ProjectYard.Domain

Placeholder para implementação futura.
